<?php
function enc_data($data) { 
	return openssl_encrypt($data, "AES-128-CBC", "icbots_enc", $options=0, $iv="icbots1234567890");
}
function dec_data($data) { 
	return openssl_decrypt($data, "AES-128-CBC", "icbots_enc", $options=0, $iv="icbots1234567890");
}

// from https://www.php.net/manual/en/function.base64-encode.php
function base64url_encode($data) { 
	return rtrim(strtr(base64_encode($data), '+/', '-_'), '='); 
}

function base64url_decode($data) { 
	return base64_decode(str_pad(strtr($data, '-_', '+/'), strlen($data) % 4, '=', STR_PAD_RIGHT)); 
}
function gen_rand_str($length){
	$chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz";//
	$rndstr="";
	
	$size = strlen( $chars );
	for( $i = 0; $i < $length; $i++ ){
		$rndchar = $chars[rand(0, $size-1)];  
		$rndstr = $rndstr . $rndchar;
	}
	return $rndstr;
}
function cache_breaker($length){
	//generate random string with specified len
	#echo "ip:" + $ip;
	
	#echo "enc: " + $encodestr;
	$ip=getenv("REMOTE_ADDR");
	#$decodestr = base64url_decode($encodestr);
	#echo "dec: " + $decodestr;

	$rndstr = gen_rand_str($length);
	$rndstr = $rndstr . $ip;	// when decode, trim out first X chars to get encoded string
	$encryptStr = enc_data($rndstr);
	$encodestr = base64url_encode($encryptStr);
	return $encodestr;
}
//this generates js file on server side, on the fly
function echo_htm(){
        $js_str = '<html>
        <header><title>Custom iframe title</title></header>
        <head> <link rel="stylesheet" href="ex.css?loc=chtm&rndstr=' . cache_breaker(20) . '"> </head>
        <body>
        customized html, with 1 image.
        <img src="' . 'vis1.jpg?loc=chtm&rndstr=' . cache_breaker(20) . '" width=1 height=1>
        </body>
        </html>';
        echo $js_str;
        echo "\n";
}
echo_htm();
?>


