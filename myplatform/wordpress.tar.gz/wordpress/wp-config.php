<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wp_db' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', 'root' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'Zrz8B0X,6^r-3$Y&I/}`.nzo2o1P)7)3dDt)i7_M)eEQN l1#$qO7)!,:!JS-|1g' );
define( 'SECURE_AUTH_KEY',  '};;| 74?Rijv}1K_`t65%$=exA7$?GbAD{*2U_Zkv3T0BHanK^zk;l]B3f,D67g>' );
define( 'LOGGED_IN_KEY',    '~k%{4+1B.ca{c|N)2zJGp%jpDJ^Rhm4ZQ&W6l2mAYolsq&5GmsF,~L8^&{+,$r!K' );
define( 'NONCE_KEY',        '=rB22!|@*~O?6lN?yeW.PA0({kqAREK#!sbe7&wT^-gOuFkmTnD1Y0>R+qcqM%>O' );
define( 'AUTH_SALT',        'WpGBKa]~ Hkj:s&5HWvW7Y=psoq3$t`|R1res)0Z<F]$q;mY`gDiber^>g9}<-rb' );
define( 'SECURE_AUTH_SALT', '3p`tATuoTPflT,)tS^Yk(j&4=vq8^gu6pQ+NZYH#]kH.R<Nr%g8:[C!}R=z$|_6_' );
define( 'LOGGED_IN_SALT',   '3wq{a<|hm$g#sCTksf29wiM}q=hd<gN.Tfk=0ngTIy-0</rdj:S08+zdldJ6L%Gu' );
define( 'NONCE_SALT',       '~b{3rI9eDutPF?&KM_-qZiy_c6R-#Bf+>aW`yc&CDww1~:GJO}|{?,X3aVZJokj+' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once( ABSPATH . 'wp-settings.php' );
