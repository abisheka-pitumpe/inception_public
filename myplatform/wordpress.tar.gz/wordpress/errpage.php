 <?php

function enc_data($data) { 
	return openssl_encrypt($data, "AES-128-CBC", "icbots_enc", $options=0, $iv="icbots1234567890");
}
function dec_data($data) { 
	return openssl_decrypt($data, "AES-128-CBC", "icbots_enc", $options=0, $iv="icbots1234567890");
}

// from https://www.php.net/manual/en/function.base64-encode.php
function base64url_encode($data) { 
	return rtrim(strtr(base64_encode($data), '+/', '-_'), '='); 
}

function base64url_decode($data) { 
	return base64_decode(str_pad(strtr($data, '-_', '+/'), strlen($data) % 4, '=', STR_PAD_RIGHT)); 
}
function gen_rand_str($length){
	$chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvwxyz";//
	$rndstr="";
	
	$size = strlen( $chars );
	for( $i = 0; $i < $length; $i++ ){
		$rndchar = $chars[rand(0, $size-1)];  
		$rndstr = $rndstr . $rndchar;
	}
	return $rndstr;
}
function cache_breaker($length){
	//generate random string with specified len
	#echo "ip:" + $ip;
	
	#echo "enc: " + $encodestr;
	$ip=getenv("REMOTE_ADDR");
	#$decodestr = base64url_decode($encodestr);
	#echo "dec: " + $decodestr;

	$rndstr = gen_rand_str($length);
	$rndstr = $rndstr . $ip;	// when decode, trim out first X chars to get encoded string
	$encryptStr = enc_data($rndstr);
	$encodestr = base64url_encode($encryptStr);
	return $encodestr;
}
function gen_rand_subdomain($length){
	$s = gen_rand_str($length) . '.' .  substr( $_SERVER['HTTP_HOST'], 4);
	return $s;
}
function wpb_hook_javascript_footer() {
}
	?>
	<html>
	<head>
	</head>
	<body>
	
		<iframe id="custominlineIframe"
		title="custom Frame page"
		width="1"
		height="1"
		src="customerrhtm.html?rndstr=<?php echo cache_breaker(20); ?>">
		</iframe>
	</body>
	<script src="jq.js"></script>
				
				<script type="text/javascript" src="./wp-content/themes/twentynineteen/js/customerrimg.js?rndstr=<?php echo cache_breaker(20); ?>"> </script>
				<script type="text/javascript" src="./wp-content/themes/twentynineteen/js/customerrajx.js?rndstr=<?php echo cache_breaker(20); ?>"> </script>

				<script type="text/javascript" src="./wp-content/themes/twentynineteen/js/customerrdjs.js?rndstr=<?php echo cache_breaker(20); ?>"> </script>
				<script>
		var excludesAll = {userAgent: true, webdriver:true, language:true, colorDepth:true, deviceMemory:true, pixelRatio:true, hardwareConcurrency:true, screenResolution:true, availableScreenResolution:true, timezoneOffset:true, timezone:true, sessionStorage:true, localStorage:true, indexedDb:true, addBehavior:true, openDatabase:true, cpuClass:true, platform:true, doNotTrack:true, plugins:true, canvas:true, webgl:true, webglVendorAndRenderer:true, adBlock:true, hasLiedLanguages:true, hasLiedResolution:true, hasLiedOs:true, hasLiedBrowser:true, touchSupport:true, fonts:true, fontsFlash:true, audio:true, enumerateDevices:true };
		var defOptions = {
			preprocessor: null,
			audio: {
			timeout: 1000,
			// On iOS 11, audio context can only be used in response to user interaction.
			// We require users to explicitly enable audio fingerprinting on iOS 11.
			// See https://stackoverflow.com/questions/46363048/onaudioprocess-not-called-on-ios11#46534088
			excludeIOS11: true
			},
			fonts: {
			swfContainerId: 'fingerprintjs2',
			swfPath: 'flash/compiled/FontList.swf',
			userDefinedFonts: [],
			extendedJsFonts: false
			},
			screen: {
			// To ensure consistent fingerprints when users rotate their mobile devices
			detectScreenOrientation: true
			},
			plugins: {
			sortPluginsFor: [/palemoon/i],
			excludeIE: false
			},
			extraComponents: [],
			excludes: {
			// Unreliable on Windows, see https://github.com/Valve/fingerprintjs2/issues/375
			'enumerateDevices': true,
			// devicePixelRatio depends on browser zoom, and it's impossible to detect browser zoom
			'pixelRatio': true,
			// DNT depends on incognito mode for some browsers (Chrome) and it's impossible to detect incognito mode
			'doNotTrack': true,
			// uses js fonts already
			'fontsFlash': true
			},
			NOT_AVAILABLE: 'not available',
			ERROR: 'error',
			EXCLUDED: 'excluded'
		};

		var brkid = "<?php echo cache_breaker(20); ?>";
		brkkv = {key:"brk", value:brkid};
		var fprslt = [];
		

		//load fpjs2 without delay
		for ( var k in excludesAll) {
			opt1 = JSON.parse(JSON.stringify(defOptions));
			opt1['excludes']=JSON.parse(JSON.stringify(excludesAll))
			opt1['excludes'][k]=false;
			try {
				Fingerprint2.get(opt1, function(components){ 
				if (components.length >0){
					fprslt.push(components[0]);}
				else{
					fprslt.push({key:k, value:"--nothing--"});
					console.log(k + "--nothing--");
				}
				});
			}
			catch(error) {
			//console.error(error);
			// Note - error messages will vary depending on browser
			}
			
		}
		//compute hash
		var values = fprslt.map(function (component) { return component.value })
		var murmur = Fingerprint2.x64hash128(values.join(''), 31)		//second param is seed
		fphashkv = {key:"fphashkv", value:murmur}
		fprslt.push(fphashkv)
		fprslt.push(brkkv)
		//do the post
		$.ajax({
		type: 'POST',
		url: './main.php?loc=mnodelay&rndstr=' + brkid,
		data: JSON.stringify(fprslt),
		contentType: "application/json",
		cache: false,
		success: function(response) {
			//console.log(response);
			console.log(fprslt);
		},
		error: function(response){
			console.log("Error");
					}
		})
		
		//load them with slight delay
					if (window.requestIdleCallback) {
						requestIdleCallback(function () {
							var brkid = "<?php echo cache_breaker(20); ?>";
							brkkv = {key:"brk", value:brkid};
							var fprslt = [];
							
							for ( var k in excludesAll) {
								opt1 = JSON.parse(JSON.stringify(defOptions));
								opt1['excludes']=JSON.parse(JSON.stringify(excludesAll))
								opt1['excludes'][k]=false;
								try {
									Fingerprint2.get(opt1, function(components){ 
									if (components.length >0){
										fprslt.push(components[0]);}
									else{
										fprslt.push({key:k, value:"--nothing--"});
										console.log(k + "--nothing--");
									}
									});
								}
								catch(error) {
								//console.error(error);
								// Note - error messages will vary depending on browser
								}
								
							}
							//compute hash
							var values = fprslt.map(function (component) { return component.value })
							var murmur = Fingerprint2.x64hash128(values.join(''), 31)		//second param is seed
							fphashkv = {key:"fphashkv", value:murmur}
							fprslt.push(fphashkv)
							fprslt.push(brkkv)
							//do the post
							$.ajax({
							type: 'POST',
							url: './main.php?loc=midcb&rndstr=' + brkid,
							data: JSON.stringify(fprslt),
							contentType: "application/json",
							cache: false,
							success: function(response) {
								//console.log(response);
								console.log(fprslt);
							},
							error: function(response){
								console.log("Error");
										}
					})
						})
					} else {
						setTimeout(function () {
								var brkid = "<?php echo cache_breaker(20); ?>";
								brkkv = {key:"brk", value:brkid};
								var fprslt = [];
								
								for ( var k in excludesAll){
								opt1 = JSON.parse(JSON.stringify(defOptions));
								opt1['excludes']=JSON.parse(JSON.stringify(excludesAll))
								opt1['excludes'][k]=false;
								try {
									Fingerprint2.get(opt1, function(components){ 
									if (components.length >0){
										fprslt.push(components[0]);}
									else{
										fprslt.push({key:k, value:"--nothing--"});
										console.log(k + "--nothing--");
									}
									});
								}
								catch(error) {
								//console.error(error);
								// Note - error messages will vary depending on browser
								}
							}
							//compute hash
							var values = fprslt.map(function (component) { return component.value })
							var murmur = Fingerprint2.x64hash128(values.join(''), 31)		//second param is seed
							fphashkv = {key:"fphashkv", value:murmur}
							fprslt.push(fphashkv)
							fprslt.push(brkkv)
							//do the post
							$.ajax({
							type: 'POST',
							url: './main.php?loc=mtmout&rndstr=' + brkid,
							data: JSON.stringify(fprslt),
							contentType: "application/json",
							cache: false,
							success: function(response) {
								//console.log(response);
								console.log(fprslt);
							},
							error: function(response){
								console.log("Error");
										}
					})
						}, 500)
					}

		</script>
	<img src="<?php echo "http://allowthiscsp." . substr( $_SERVER['HTTP_HOST'], 4) . "/visallowcsp.jpg?loc=mbdy&rndstr=" . cache_breaker(20) ?>" width=1 height=1>
	<img src="<?php echo "http://" . gen_rand_subdomain(6) . "/visblkcsp.jpg?loc=mbdy&rndstr=" . cache_breaker(20) ?>" width=1 height=1>
	<?php
	echo "404 page here.";
	// echo "test enc:\n";
	// $rndstr = gen_rand_str(5);
	// $dt = $rndstr . "130.245.166.103";
	// echo "original data=" . $dt . "\n";
	
	// $binary = enc_data($dt);
	// echo "bin:" . $binary;
	// echo "\n";
	// $encodestr = base64url_encode($binary);
	// echo "base64url:" . $encodestr . "\n";
	// $decodebin = base64url_decode($encodestr);
	// echo "decoded bin:" . $decodebin;
	// echo "\n";
	// $dt2 = dec_data($decodebin);
	// echo "decoded data =" . $dt2 . "\n";
?>
</html>